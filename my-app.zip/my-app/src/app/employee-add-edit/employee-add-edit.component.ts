import { Component } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MatDialogActions,
  MatDialogClose,
  MatDialogTitle,
  MatDialogContent,
} from '@angular/material/dialog';
import { MatDatepickerModule } from '@angular/material/datepicker';

import { MAT_DIALOG_DATA } from '@angular/material/dialog';

import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatButtonModule } from '@angular/material/button';
import { MatRadioModule } from '@angular/material/radio';
import { provideNativeDateAdapter } from '@angular/material/core';

import { MatSelectModule } from '@angular/material/select';
import { EmployeeService } from '../services/employee.service';

interface Education {
  value: string;
  viewValue: string;
}

@Component({
  selector: 'app-employee-add-edit',
  standalone: true,
  providers: [provideNativeDateAdapter()],
  imports: [
    MatButtonModule,
    MatRadioModule,
    MatSelectModule,
    MatDialogActions,
    MatDialogClose,
    MatDialogTitle,
    MatDialogContent,
    FormsModule,
    MatInputModule,
    MatFormFieldModule,
    MatDatepickerModule,
    ReactiveFormsModule
  ],
  templateUrl: './employee-add-edit.component.html',
  styleUrl: './employee-add-edit.component.css',
})
export class EmployeeAddEditComponent {
  
  name: string = 'RAhul';
  empForm: FormGroup;
  educations: Education[] = [
    { value: 'MBA', viewValue: 'Master of Business Administration' },
    { value: 'BBA', viewValue: 'Bachelor of Business Administration' },
    { value: 'BCA', viewValue: 'Bachelor of Computer Administration' },
  ];
  constructor(public dialogRef: MatDialogRef<EmployeeAddEditComponent>, private _fb: FormBuilder, private _empService: EmployeeService) {
    this.empForm = this._fb.group({
      firstName: "",
      lastName: "",
      email: "",
      dob: "",
      gender: "",
      education: "",
      company: "",
      experience: "",
      package: ""
    });
  }

  onFormSubmit() {
    if(this.empForm.valid) {
      console.log(this.empForm.value);
      this._empService.addEmployee(this.empForm.value).subscribe((res) => {
        console.log(res);
      })
    }
  }
}
